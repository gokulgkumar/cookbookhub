from django.apps import AppConfig


class CookbookhubAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'CookbookHub_app'
